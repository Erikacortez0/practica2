﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Tomar etiqueta y asignarle un cambio en el contenido mediante el evento click del boton.

            label1.Text = "antes del evento";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Tomar etiqueta y asignarle un cambio en el contenido mediante el evento click del boton.

            label1.Text = "Despues del evento";
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //modificando el panel para que cambie de color aleatoriamente
            // con backColory su propiedad de Color.FromArgb
            //Cambiamos de color y con new random le generamos un color 
            //.Net asignamos valor siguiente 
            Random random = new Random();
            panel1.BackColor = Color.FromArgb(random.Next(257), random.Next(258), random.Next(256), random.Next(255)) ;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void cambiar_Click(object sender, EventArgs e)
        {
            
        }
    }
}
